from generateDictTechniques import *
from cleanTextTechniques import *

vb_docs = pd.read_csv('./assets/verbs-all.csv')

""" main function for text preprocessing """
""" Clean text """
def cleanText(data):
    sentences = []
    for line in data.split('\n'):
        """ ===== Noise removal ===== """
        line = removeHtmlTag(line)
        line = convertHtmlUnescape(line)
        line = removeUnicode(line)
        line = removeTwitterUser(line)
        line = removeURL(line)
        line = removeHashtag(line)
        """ ===== Remove main ===== """
        line = removeBracket(line)
        line = removePunctation(line)
        line = removeEmoticons(line) # removes emoticons from text
        line = convertLowercase(line)
        line = removeNumbers(line)
        line = removeWhiteSpace(line)
        sentences += splitSentences(line)
    return sentences


""" Generate Dictionary """
def generateDictionary(sentences, isDict):
    tokenize_dict = []
    dict = []
    lemma_dict = []
    remove_stopword_dict = []
    curr_pronoun_list = ['', '', '', '']
    prev_pronoun_list = ['', '', '', '']
    replaced_pronoun_dict = []
    tokenize_dict = []
    stemmed_dict = []

    for sentence in sentences:
        tokenize_text = tokenize(sentence)
        tokenize_dict += tokenize_text
        POS_tag = posTaggingForLem(tokenize_text)
        POS_tag = convertVBtoJJ(POS_tag, vb_docs)
        lemmatized_text = lemmatization(POS_tag)
        lemma_dict += lemmatized_text
        POS_tag = posTaggingForFiltering(lemmatized_text)
        stopwords = posBasedFiltering(POS_tag)
        stopwords_plus = completeStopwordGeneration(stopwords)
        removed_stopword = removingStopwords(lemmatized_text, stopwords_plus)
        curr_pronoun_list = createPronounList(removed_stopword, prev_pronoun_list)
        replaced_pronoun = replacePronoun(removed_stopword, curr_pronoun_list)
        prev_pronoun_list = curr_pronoun_list

        if isDict:
            replaced_pronoun_dict.append(replaced_pronoun)
        else:
            replaced_pronoun_dict += replaced_pronoun

    return replaced_pronoun_dict
