#!/usr/bin/python3
from flask import (Flask, request, jsonify, json)
from flask_cors import CORS
import numpy as np
import re
from nltk.translate.bleu_score import sentence_bleu
import pandas as pd
from main import *
from generateDictTechniques import *

app = Flask(__name__)

"""Cross-Origin Resource Sharing (CORS)"""
cors = CORS(app, resources={r"/*": {"origins": "*"}})

""" ===== Initialize the data and Variable ===== """
""" Tokenizes a text to its words, removes and replaces some of them """
print("Text preprocessing demo starting...")

""" ===== Declare file path ===== """
movie_spoiler_file_path = "./assets/movie-spoiler/the-movie-spoiler.txt"
imdb_file_path = "./assets/movie-spoiler/imdb-spoil.txt"
movie_pooper_file_path = "./assets/movie-spoiler/movie-pooper.txt"

""" ===== Load file ===== """

movie_spoiler_data = loadSampleData(movie_spoiler_file_path) # 1st techniques
imdb_data  = loadSampleData(imdb_file_path)
movie_pooper_data = loadSampleData(movie_pooper_file_path)

movie_spoiler_data = movie_spoiler_data + imdb_data + movie_pooper_data

""" Text preprocessing """

imdb_sentences = cleanText(imdb_data)
movie_spoiler_sentences  = cleanText(movie_spoiler_data)
movie_pooper_sentences  = cleanText(movie_pooper_data)

""" Generate Dictionary """
movie_spoiler_dict = generateDictionary(movie_spoiler_sentences, True)
imdb_dict = generateDictionary(imdb_sentences, True)
movie_pooper_dict = generateDictionary(movie_pooper_sentences, True)

"""  Combined Dictionary """

combined_dict = movie_spoiler_dict + imdb_dict + movie_pooper_dict

""" URL for request """
""" Send the content from google news, twitter, facebook """
@app.route('/get-spoil-and-send-score', methods = ['POST'])
def response_score():
    if request.method == "POST":
        spoil_suspect = request.form.get('spoil_suspect', None)
        spoil_suspect = cleanText(spoil_suspect)
        spoil_dict = generateDictionary(spoil_suspect, False)
        score = sentence_bleu(movie_spoiler_dict, spoil_dict)
    return str(score)
